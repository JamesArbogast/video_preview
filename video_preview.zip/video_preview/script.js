function playVideo() {
    document.getElementById("video").play();
}
function pauseVideo() {
    document.getElementById("video").pause();
}